import Layout from "../components/Layout";
import HeroBusiness from "../components/HeroBusiness";
import HeroCreative from "../components/HeroCreative";
import Features from "../components/Features";
import WaitlistForm from "../components/WaitlistForm";

export default function Home({ lang, setLang, variant, setVariant }) {
  const onJoin = () => {
    const el = document.getElementById("waitlist");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <Layout variant={variant}>
      <div className="max-w-6xl mx-auto px-6 py-4 flex justify-end gap-4">
        <select value={lang} onChange={(e)=>setLang(e.target.value)} className="border p-2 rounded">
          <option value="en">English</option>
          <option value="pl">Polski</option>
          <option value="de">Deutsch</option>
        </select>

        <div className="flex items-center gap-2">
          <label className="text-sm mr-2">{variant === "creative" ? "Creative" : "Business"}</label>
          <button onClick={()=>setVariant(variant==="business"?"creative":"business")} className="px-3 py-1 border rounded">
            {variant === "business" ? "Switch to Creative" : "Switch to Business"}
          </button>
        </div>
      </div>

      {variant === "business" ? <HeroBusiness onJoin={onJoin} variant={variant}/> : <HeroCreative onJoin={onJoin}/>}

      <Features variant={variant}/>
      <WaitlistForm variant={variant}/>
    </Layout>
  );
}