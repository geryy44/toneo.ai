import "../styles/globals.css";
import { useState } from "react";

export default function MyApp({ Component, pageProps }) {
  const [lang, setLang] = useState("en");
  const [variant, setVariant] = useState("business");
  return (
    <Component {...pageProps} lang={lang} setLang={setLang}
               variant={variant} setVariant={setVariant} />
  );
}