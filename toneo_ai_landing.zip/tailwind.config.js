/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}"
  ],
  theme: {
    extend: {
      colors: {
        toneoBlue: "#0b6cff",
        toneoPurple: "#7c3aed"
      }
    }
  },
  plugins: []
}